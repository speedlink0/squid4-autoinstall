/*
 * Copyright (C) 1996-2016 The Squid Software Foundation and contributors
 *
 * Squid software is distributed under GPLv2+ license and includes
 * contributions from numerous individuals and organizations.
 * Please see the COPYING and CONTRIBUTORS files for details.
 */

/* DEBUG: section 47    Store Directory Routines */

/* TODO: remove this file as unused */

#include "squid.h"
#include "fs/ufs/StoreFSufs.h"
#include "fs/ufs/UFSSwapDir.h"

/**
 \defgroup AUFS AUFS Storage Filesystem (UFS Based)
 \ingroup UFS, FileSystems
 */

/* Unused variable: */

